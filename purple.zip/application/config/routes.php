<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['about_us'] = 'Home/about_us';
$route['contact_us'] = 'Home/contact_us';
$route['get_involved'] = 'Home/get_involved';
$route['registration_form'] = 'Home/registration_form';
$route['testimonial'] = 'Home/testimonial';
$route['our_product'] = 'Home/our_product';
$route['our_project'] = 'Home/our_project';
$route['terms'] = 'Home/terms';
$route['donation'] = 'Home/donation';
$route['policy'] = 'Home/policy';
$route['gallery'] = 'Home/gallery';
$route['testimonial'] = 'Home/testimonial';
$route['annual_report'] = 'Home/annual_report';
$route['career'] = 'Home/career';
$route['blog'] = 'Home/blog';
$route['blog_details'] = 'Home/blog_details';

