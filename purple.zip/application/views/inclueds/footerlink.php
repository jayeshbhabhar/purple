<a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="icon-up-arrow"></i></a>


    <script src="<?= base_url() ?>assets/vendors/jquery/jquery-3.6.0.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/jarallax/jarallax.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/jquery-appear/jquery.appear.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/jquery-validate/jquery.validate.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/nouislider/nouislider.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/odometer/odometer.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/swiper/swiper.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/tiny-slider/tiny-slider.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/wnumb/wNumb.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/wow/wow.js"></script>
    <script src="<?= base_url() ?>assets/vendors/isotope/isotope.js"></script>
    <script src="<?= base_url() ?>assets/vendors/countdown/countdown.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/owl-carousel/owl.carousel.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/bxslider/jquery.bxslider.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/bootstrap-select/js/bootstrap-select.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/vegas/vegas.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/jquery-ui/jquery-ui.js"></script>
    <script src="<?= base_url() ?>assets/vendors/timepicker/timePicker.js"></script>
    <script src="<?= base_url() ?>assets/vendors/circleType/jquery.circleType.js"></script>
    <script src="<?= base_url() ?>assets/vendors/circleType/jquery.lettering.min.js"></script>




    <!-- template js -->
    <script src="<?= base_url() ?>assets/js/oxpins.js"></script>
    